import tkinter as tk
from tkinter import simpledialog
import random

class BankAccount:
    def __init__(self, holder="", account_type=0, balance=0.0):
        """
        Initialize a new BankAccount object.
        - holder: Name of the account holder (default is an empty string).
        - account_type: Type of account (0 = Checking, 1 = Savings, 2 = High-Interest).
        - balance: Initial account balance (default is 0.0).
        """
        self.accountHolder = holder
        self.accountType = account_type
        self.accountNum = random.randint(0, 10000)  # Randomly generate a unique account number.
        self.accountBalance = balance

    def accountDeposit(self):  # Prompt the user to enter an amount to deposit and add it to the account balance.
        amount = self._get_numeric_input("Deposit", "Enter amount to deposit:")
        if amount > 0:
            self.accountBalance += amount

    def accountWithdrawal(self):   # Prompt the user to enter an amount to withdraw and subtract it from the account balance.
        amount = self._get_numeric_input("Withdrawal", "Enter amount to withdraw:")
        if amount > 0:
            self.accountBalance -= amount

    def _get_numeric_input(self, title, prompt):
        """
        Helper function to repeatedly prompt the user for a numeric input.
        - title: Title of the dialog box.
        - prompt: Instructional text to show the user.
        """
        while True:
            inp = simpledialog.askstring(title, prompt)  # Prompt user for input.
            if inp and inp.isnumeric():  # Validate input is numeric.
                return int(inp)

    def accountSetup(self):  # Set up the account by prompting the user for account holder's name, account type, and initial balance.

        # Get account holder's name.
        self.accountHolder = simpledialog.askstring("Banking", "Enter account name:")

        # Get and validate account type (0, 1, or 2).
        self.accountType = self._get_account_type()

        # Get initial balance as a numeric input.
        self.accountBalance = self._get_numeric_input("Banking", "Enter initial balance (whole numbers only):")

    def _get_account_type(self):  # Helper function to repeatedly prompt the user for a valid account type (0, 1, or 2).
        while True:
            inp = simpledialog.askstring(
                "Banking",
                "Enter account type (0 for Checking, 1 for Savings, 2 for High-Interest):"
            )
            if inp and inp.isnumeric():
                account_type = int(inp)
                return max(0, min(2, account_type))  # Ensure account type is within valid range.


class BankSystem:
    def __init__(self):
        """
        Initialize a new BankSystem to manage multiple accounts.
        - accountList: A list to store all BankAccount objects.
        - accountIndex: A dictionary to map account holder names to their indices in accountList.
        """
        self.accountList = []
        self.accountIndex = {}

    def addAccount(self):
        """
        Create a new account and add it to the system.
        Updates both the account list and the name-to-index dictionary for fast lookups.
        """
        new_account = BankAccount()  # Create a new BankAccount object.
        new_account.accountSetup()  # Set up account details (name, type, balance).

        # Add the new account to the list and index it by account holder's name.
        self.accountList.append(new_account)
        self.accountIndex.setdefault(new_account.accountHolder, []).append(len(self.accountList) - 1)

        # Allow the user to deposit and withdraw from the account after setup.
        new_account.accountDeposit()
        new_account.accountWithdrawal()

        # Print the current state of all accounts for debugging purposes.
        self._debug_accounts()

    def findAccount(self, c):
        """
        Find an account by holder's name and perform an action (deposit or withdrawal).
        - c: Action to perform (1 = Deposit, 2 = Withdrawal).
        """
        inp = simpledialog.askstring("Account Search", "Enter account holder's name:")
        if inp not in self.accountIndex:
            print("No accounts found for this name.")
            return

        # Retrieve all account positions for the given name.
        positions = self.accountIndex[inp]
        selected_pos = None

        # If multiple accounts are found, prompt the user to select one by account number.
        if len(positions) > 1:
            account_nums = [self.accountList[i].accountNum for i in positions]
            account_choice = simpledialog.askstring(
                "Account Search",
                f"Multiple accounts found: {account_nums}. Enter account number:"
            )
            selected_pos = next((positions[i] for i, num in enumerate(account_nums) if str(num) == account_choice), None)
        else:
            selected_pos = positions[0]  # Use the single matching account.

        if selected_pos is not None:
            # Perform the selected action (deposit or withdrawal).
            if c == 1:
                print(f"Depositing into account at position {selected_pos}.")
                self.accountList[selected_pos].accountDeposit()
            elif c == 2:
                print(f"Withdrawing from account at position {selected_pos}.")
                self.accountList[selected_pos].accountWithdrawal()
        else:
            print("No valid account selected.")

    def _debug_accounts(self):
        #  Print the details of all accounts in the system for debugging purposes.
        print("Current Accounts:")
        for acc in self.accountList:
            print(f"Holder: {acc.accountHolder}, Num: {acc.accountNum}, Type: {acc.accountType}, Balance: {acc.accountBalance}")


bank_system = BankSystem()
bank_system.addAccount()  # Add a new account to the system.
