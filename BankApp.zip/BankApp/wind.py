import tkinter

import accounts, time
from accounts import BankAccount
from tkinter import *
from tkinter.ttk import *

accountStr = []

class NewWindow(Toplevel):
    def __init__(self, master = None):
        super().__init__(master = master)
        self.title("Meyer Banking")
        self.geometry("500x200")
        label = Label(self, text = "Welcome to Meyer Banking")
        label.pack

def sortBy(accountList, f):
    startTime = time.process_time()
    T.delete('1.0',tkinter.END)
    i = 0
    accountStr = []

    #Sort by Name
    if f == 0: accountList = sorted(accountList, key = lambda x: x.accountHolder)
    #Sort by Account #
    if f == 1: accountList = sorted(accountList, key=lambda x: x.accountNum)
    #Sort by Account Balance
    if f == 2: accountList = sorted(accountList, key=lambda x: x.accountBalance, reverse = True)



    #Output results
    while i < len(accountList):
        #Produce a string from account information
        testStr = str(accountList[i].accountNum) + "," + str(accountList[i].accountHolder) + "," + str(accountList[i].accountType) + "," + str(accountList[i].accountBalance)
        testStr = str(testStr) + "\n"

        #Remove brackets
        testStr.replace("{"," ")
        testStr.replace("}"," ")
        testStr.replace("(", " ")
        testStr.replace(")", " ")

        #Add string to array, then add to text object
        accountStr.append(testStr)
        T.insert(END,accountStr[i])
        i += 1

    # Get Time
    finalTime = time.process_time()
    finalTime = finalTime - startTime

    print ("Executed in: " + str(finalTime) + " seconds.")

master = Tk()
master.geometry("500x500")
label = Label(master, text = "Welcome to Meyer Banking")
label.pack(side = TOP, pady = 10)
T = Text(master, height = 10, width = 52)



#New Account Setup
nAcc = Button(text = "New Account")
nAcc.bind("<Button>", lambda e: accounts.newAccount())
#Find Accounts
fAcc = Button(text = "Find Account")
fAcc.bind("<Button>", lambda e: accounts.findAccount(0))
#Deposit into Account
dAcc = Button(text = "Deposit into Account")
dAcc.bind("<Button>", lambda e: accounts.findAccount(1))
#Withdraw from Account
wAcc = Button(text = "Withdraw from Account")
wAcc.bind("<Button>", lambda e: accounts.findAccount(2))
#Sort by Name
snaAcc = Button(text = "Sort by Name")
snaAcc.bind("<Button>", lambda e: sortBy(accounts.accountList,0))
#Sort by Account #
snuAcc = Button(text = "Sort by Account #")
snuAcc.bind("<Button>", lambda e: sortBy(accounts.accountList,1))
#Sort by Balance
sbAcc = Button(text = "Sort by Balance")
sbAcc.bind("<Button>", lambda e: sortBy(accounts.accountList,2))

nAcc.pack(padx = 5, pady = 1.25)
fAcc.pack(padx = 5, pady = 1.25)
dAcc.pack(padx = 5, pady = 1.25)
wAcc.pack(padx = 5, pady = 1.25)
snaAcc.pack(padx = 5, pady = 1.25)
snuAcc.pack(padx = 5, pady = 1.25)
sbAcc.pack(padx = 5, pady = 1.25)

T.pack(padx = 5, pady = 2)


mainloop()