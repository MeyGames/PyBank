import tkinter as tk
from tkinter import simpledialog
import random

class BankAccount:

    def __init__(self):
        self.accountHolder = ""
        self.accountType = 0
        self.accountNum = random.randint(0,10000)
        self.accountBalance = 0.0
    def accountDeposit(self):
        inp = ""
        while not inp.isnumeric: inp = simpledialog.askstring("Deposit","Select amount to deposit")
        if inp.isnumeric(): self.accountBalance += int(inp)
    def accountWithdrawal(self):
        inp = ""
        while not inp.isnumeric: inp = simpledialog.askstring("Withdrawal", "Select amount to withdraw")
        if inp.isnumeric(): self.accountBalance -= int(inp)
    def accountSetup(self):
        self.accountHolder = simpledialog.askstring("Banking","Please enter account name")
        inp = ""
        while not inp.isnumeric():
            inp = simpledialog.askstring("Banking","Please enter account type <0 for checking, 1 for savings, 2 for high-interest>:")
            if int(inp) < 0: self.accountType = 0
            elif int(inp) > 2: self.accountType = 2
            else: self.accountType = int(inp)

        inp = ""
        while not inp.isnumeric():
            inp = simpledialog.askstring("Banking","Please input initial balance (whole numbers only): ")
        if float(inp) > 0: self.accountBalance = float(inp)

accountList = []

def newAccount():
    accountList.append(BankAccount())
    accountList[len(accountList) - 1].accountSetup()
    accountList[len(accountList) - 1].accountDeposit()
    accountList[len(accountList) - 1].accountWithdrawal()

    i = 0
    print("Debug for this call:")
    while i < len(accountList):
        print(accountList[i].accountHolder + ", " + str(accountList[i].accountNum) + ", " + str(accountList[i].accountType) + ", " +  str(accountList[i].accountBalance))
        i += 1


def findAccount(c):
    #C refers to the input fed into a switch statement that determines what internal function is called at the end of the search.
    inp = simpledialog.askstring("Account Search","Please enter holder name")
    i = 0
    an = [] #Array of account numbers
    ap = [] #Array of valid positions in main array
    fp = [] #Final position

    while i < len(accountList):
        if not inp.isnumeric():
            if accountList[i].accountHolder == inp:
                print("Match found!")
                an.append(accountList[i].accountNum)
                ap.append(i)
        i += 1

    #Narrow down
    if len(an) > 1:
        inp = simpledialog.askstring("Account Search","We have found multiple accounts: " + str(an) + ". Which one did you have in mind?")
        i = 0

        while i < len(an):
            if an[i] == int(inp): fp = ap[i]
            i += 1
    else: fp = ap[0]
    print(fp)

    inp = ""

    if c == 1:
        print("Deposit for account at " + str(fp) + " in list.")
        accountList[fp].accountDeposit()
    elif c == 2:
        print("Withdraw for account at " + str(fp) + " in list.")
        accountList[fp].accountWithdrawal()

    #Switch statement to call next method